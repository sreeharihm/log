import { Component, ViewChild } from '@angular/core';
import {} from 'googlemaps';
import { ChartType } from 'chart.js';
import { MultiDataSet, Label } from 'ng2-charts';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [DatePipe]
})
export class AppComponent {
  title = 'materialAppv2';
  public filterOption = "";
  public productFields: string[] = ['name', 'code', 'expirationDate', 'category', 'status', 'action'];
  public products: any = [
    {
        "id": "213",
        "code": "Ivan C Prime",
        "name": "New User",
        "category": 0,
        "categoryId": "R",
        "expirationDate": "2021-09-21T16:46:36.459Z",
        "status": true
    },
    {
      "id": "213",
      "code": "Ivan C Prime",
      "name": "New User",
      "category": 0,
      "categoryId": "R",
      "expirationDate": "2021-09-21T16:46:36.459Z",
      "status": true
  },
  {
    "id": "213",
    "code": "Ivan C Prime",
    "name": "New User",
    "category": 0,
    "categoryId": "R",
    "expirationDate": "2021-09-21T16:46:36.459Z",
    "status": true
}
  ]
  public doughnutChartLabels: Label[] = ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'];
  public doughnutChartData: MultiDataSet = [
    [350, 450, 100],
    [50, 150, 120],
    [250, 130, 70],
  ];
  public doughnutChartType: ChartType = 'doughnut';
  public today;
  public yesterday;
  @ViewChild('map') gMapEl: any;
  map!: google.maps.Map;
  constructor(private datePipe: DatePipe) {
    const date = new Date();
    this.today = this.datePipe.transform(date,'MM/dd/yyyy');
    this.yesterday = this.datePipe.transform(date.setDate(date.getDate() - 1),'MM/dd/yyyy');
    this.products.filterPredicate = (data: any, filter: string) => 
        !filter || data.expirationDate.includes(filter);
  }
  ngOninit() {
    const gMapProps = {
      center: new google.maps.LatLng(35.2271, -80.8431),
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    this.map = new google.maps.Map(this.gMapEl.nativeElement, gMapProps);
  }
  
  filterByDate(filterValue: any) {
    this.filterOption = filterValue;
    this.products.filter = filterValue.trim();
  }

  public chartClicked({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }

  public chartHovered({ event, active }: { event: MouseEvent, active: {}[] }): void {
    console.log(event, active);
  }
}
